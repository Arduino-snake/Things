# NOVA Shader MCPE
An aesthetic lightweight shader for Minecraft BE/PE (GLSL)

#### [Download beta (119b)](https://github.com/devendrn/NOVA-shader-mcbe/archive/main.zip)  
#### [Customisation](https://devendrn.github.io/NOVA-shader/customization.html)  
#### [Contribution](/.docs/contribution.md)  
#### [MCPEDL Post](https://mcpedl.com/NOVA-shader/)  
#### [https://discord.gg/RjJtVuNt)