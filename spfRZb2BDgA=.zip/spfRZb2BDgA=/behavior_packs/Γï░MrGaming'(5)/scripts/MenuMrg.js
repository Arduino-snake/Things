import {
    ActionFormData} from "@minecraft/server-ui";

export function MRG(source) {
    const mrg = new ActionFormData()
        .title("Created by§f: §5mrgamingisop §0<- §4YouTube")
        .button('§8[§cExit§8]', 'textures/ui/icon_import.png');
        mrg.body("§ev1.0.1 \n§4§lWARNING§0§r: §fThere is no undo yet, make sure to backup your world.")
        mrg.button('§8[§cActivate§8]\n§r§7Tap to open', 'textures/ui/hammer_l.png')
    mrg.show(source).then(({ selection }) => { // MAIN MENU
        switch (selection) {
            case 0:
                source.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§¶§6MRG BUILDER ► §dMENU §cCLOSED."}]}`)
                break;
            case 1:
                source.runCommandAsync(`scoreboard players add @s mrg 1`)
                break;
        }
    });
}