import {
  world,
  system
} from "@minecraft/server";
import {
  MRG
} from "./MenuMrg"

world.beforeEvents.itemUse.subscribe(({
  source,
  itemStack
}) => {
  system.run(() => {
      switch (itemStack.typeId) {
          case "mrg:mrgamingisop_menu":
              MRG(source);
              break;
      }
  });
});